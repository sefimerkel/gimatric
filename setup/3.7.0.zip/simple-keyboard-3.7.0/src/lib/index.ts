import "./polyfills";
import SimpleKeyboard from "./components/Keyboard";
export * from "./interfaces";
export { SimpleKeyboard };
export default SimpleKeyboard;
